﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculateOhm;

namespace TestOhmCalc
{
	[TestFixture]
	class TestOhm
	{
		[TestCase]
		public void TestA()
		{
			OhmValueCalculator ovc = new OhmValueCalculator();
			Assert.AreEqual(12, ovc.CalculateOhmValue("Green", "Green", "Green", "Green"));

		}
	}
}
