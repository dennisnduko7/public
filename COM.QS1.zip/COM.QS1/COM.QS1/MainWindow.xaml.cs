﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CalculateOhm;
namespace COM.QS1
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private Dictionary<string, string> Band_D = new Dictionary<string, string>();
		public MainWindow()
		{
			InitializeComponent();
			Band_D.Add("Brown", "(+/- 1%)");
			Band_D.Add("Red", "(+/- 2%)");
			Band_D.Add("Green", "(+/- 0.5%)");
			Band_D.Add("Gold", "(+/- 5%)");
			Band_D.Add("Silver", "(+/- 10%)");
			Band_D.Add("Yellow", "(+/- 5%)");
			Band_D.Add("Blue", "(+/- 0.25%)");
			Band_D.Add("Violet", "(+/- 0.1%)");
			Band_D.Add("Grey", "(+/- 0.05%)");
			Band_D.Add("White", " ");
			Band_D.Add("Pink", " ");
			Band_D.Add("Black", " ");
			Band_D.Add("Orange", " ");
			Band_D.Add("None", "(+/- 20%)");
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			string bandA = c1.Text;
			string bandB = c2.Text;
			string bandC = c3.Text;
			string bandD = c4.Text;
			IOhmValueCalculator oh = new OhmValueCalculator();
			try
			{
				MyTextBlock.Text = "" + ((double)oh.CalculateOhmValue(bandA, bandB, bandC, bandD)) / 1000 + "K " + Band_D[bandD];
			}
			catch(Exception ew) {
			}
		}

	}
}
