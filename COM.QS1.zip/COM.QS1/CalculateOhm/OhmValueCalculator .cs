﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculateOhm
{
	public class OhmValueCalculator : IOhmValueCalculator
	{
		private Dictionary<string, int> Band_A;
		private Dictionary<string, int> Band_B;
		private Dictionary<string, int> Band_C;
		
		public OhmValueCalculator()
		{
			/*
			 *To old the values of the bands
			 */
			Band_A = new Dictionary<string, int>();
			Band_B = new Dictionary<string, int>();
			Band_C = new Dictionary<string, int>();
			//Band_D = new Dictionary<string, double>();
			String Colors = "Black Brown Red Orange Yellow Green Blue Violet Grey White";
			String[] col = Colors.Split().ToArray();
			int count = 0;
			foreach (string st in col)
			{
				Band_A.Add(st, count);//values for band a
				Band_B.Add(st, count);//values fro band b
				Band_C.Add(st, (int)Math.Pow(10,count));//values for band c
				//Band_D.Add(st, 0);
				count++;
			}
		}
		/// <summary>
		/// CalculateOhmValue
		/// </summary>
		/// <param name="bandAColor"></param>
		/// <param name="bandBColor"></param>
		/// <param name="bandCColor"></param>
		/// <param name="bandDColor"></param>
		/// <returns></returns>
		public int CalculateOhmValue(string bandAColor, string bandBColor, string bandCColor, string bandDColor) 
		{
			return (Band_A[bandAColor]*10 + Band_B[bandBColor])*Band_C[bandCColor];
		}
	}
}
