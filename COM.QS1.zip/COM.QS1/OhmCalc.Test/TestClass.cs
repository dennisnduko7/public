﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculateOhm;
namespace OhmCalc.Test
{
	//Test OhmValueCalculator
	[TestFixture]
	public class TestClass
	{
		OhmValueCalculator testOhm;

		[SetUp]
		public void SetUpTest()
		{
			testOhm = new OhmValueCalculator();
		}
		[TestCase]
		public void TestCalculateOhmValue()
		{
			Assert.AreEqual(56, testOhm.CalculateOhmValue("Green", "Blue", "Black", "Black"));
			Assert.AreEqual(22000, testOhm.CalculateOhmValue("Red", "Red", "Orange", "Gold"));
			Assert.AreEqual(470, testOhm.CalculateOhmValue("Yellow", "Violet", "Brown", "Black"));
			Assert.AreEqual(68, testOhm.CalculateOhmValue("Blue", "Grey", "Black", "Gold"));

		}

	}
}
